import express from 'express';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import cors from 'cors'; 

// Cargar variables de entorno
dotenv.config();

// Importar Rutas
import profile_routes from './routes/ProfileRoute.js';
import state_routes from './routes/StateRoute.js';
import category_routes from './routes/CategoryRoute.js';
import new_routes from './routes/NewRoute.js';
import user_routes from './routes/UserRoute.js';

// Conexión a la base de datos
mongoose.connect(process.env.MONGODB_URI)
    .then(() => console.log('✅ Conectado a MongoDB'))
    .catch((err) => console.error('❌ Error al conectar a MongoDB:', err));

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// Usar las rutas
app.use('/api', profile_routes);
app.use('/api', state_routes);
app.use('/api', category_routes);
app.use('/api', new_routes);
app.use('/api', user_routes);

app.listen(PORT, () => {
    console.log(`🚀 Servidor escuchando en el puerto ${PORT}`);
});

export default app;