import express from 'express';
import { get, getById, create, update, destroy } from '../controllers/CategoryController.js';
// Importa los validadores
import { validatorCategoryCreate, validatorCategoryUpdate } from '../validators/CategoryValidator.js';

const api = express.Router();

api.get('/categories', get);
api.get('/categories/:id', getById);
// Usa el validador al crear
api.post('/categories', validatorCategoryCreate, create);
// Usa el validador al actualizar
api.put('/categories/:id', validatorCategoryUpdate, update);
api.delete('/categories/:id', destroy);

export default api;