import express from 'express';
import { get, getById, create, update, destroy } from '../controllers/UserController.js';
// Importa los validadores que acabamos de crear
import { validatorUserCreate, validatorUserUpdate } from '../validators/UserValidator.js';

const api = express.Router();

api.get('/users', get);
api.get('/users/:id', getById);
// Aplica los validadores a las rutas correspondientes
api.post('/users', validatorUserCreate, create);
api.put('/users/:id', validatorUserUpdate, update);
api.delete('/users/:id', destroy);

export default api;