import express from 'express';
import { get, getById, create, update, destroy } from '../controllers/NewController.js';
// Importa los validadores
import { validatorNewCreate, validatorNewUpdate } from '../validators/NewValidator.js';

const api = express.Router();

api.get('/news', get);
api.get('/news/:id', getById);
// Aplica el validador antes de la función 'create' del controlador
api.post('/news', validatorNewCreate, create);
// Aplica el validador antes de la función 'update' del controlador
api.put('/news/:id', validatorNewUpdate, update);
api.delete('/news/:id', destroy);

export default api;