import express from 'express';
import { get, getById, create, update, destroy } from '../controllers/StateController.js';
import { validatorStateRequire, validatorStateOptional } from '../validators/StateValidator.js';

const api = express.Router();

api.get('/states', get);
api.get('/states/:id', getById);
api.post('/states', validatorStateRequire, create);
api.put('/states/:id', validatorStateOptional, update);
api.delete('/states/:id', destroy);

export default api;