const express = require('express');
const router = express.Router();

// Nuestro "almacén" de datos en memoria. En una aplicación real, esto sería una base de datos.
let usuarios = [
    {id: 1, nombre: "Math Jhon", edad: 25},
    {id: 2, nombre: "Ana García", edad: 30},
    {id: 3, nombre: "Pedro Pascal", edad: 48},
    {id: 4, nombre: "Lucía Martin", edad: 22},
    {id: 5, nombre: "Carlos Ruiz", edad: 35}
];

// 1. RUTA PARA OBTENER TODOS LOS USUARIOS (CON FILTRADO OPCIONAL)
// Ejemplo de consulta: GET /api/usuarios?edad=30
router.get('/usuarios', (req, res) => {
    // Obtenemos los posibles filtros desde los query params
    const { nombre, edad } = req.query;
    let usuariosFiltrados = [...usuarios];

    // Si se proporciona un 'nombre' en la consulta, filtramos
    if (nombre) {
        usuariosFiltrados = usuariosFiltrados.filter(u => u.nombre.toLowerCase().includes(nombre.toLowerCase()));
    }

    // Si se proporciona una 'edad' en la consulta, filtramos sobre el resultado anterior
    if (edad) {
        usuariosFiltrados = usuariosFiltrados.filter(u => u.edad == parseInt(edad));
    }

    res.json(usuariosFiltrados);
});

// 2. RUTA PARA OBTENER UN USUARIO POR SU ID
// Ejemplo: GET /api/usuarios/3
router.get('/usuarios/:id', (req, res) => {
    // Obtenemos el ID de los parámetros de la ruta y lo convertimos a número
    const userId = parseInt(req.params.id);
    const usuario = usuarios.find(u => u.id === userId);

    // Si encontramos el usuario, lo devolvemos. Si no, un error 404.
    if (usuario) {
        res.json(usuario);
    } else {
        res.status(404).json({ message: 'Usuario no encontrado' });
    }
});

// 3. RUTA PARA AGREGAR UN NUEVO USUARIO
// Ejemplo: POST /api/usuarios con un body JSON
router.post('/usuarios', (req, res) => {
    const { nombre, edad } = req.body;

    // Validación simple
    if (!nombre || !edad) {
        return res.status(400).json({ message: 'El nombre y la edad son requeridos' });
    }

    // Creamos un nuevo ID (el más alto + 1)
    const nuevoId = Math.max(...usuarios.map(u => u.id)) + 1;

    const nuevoUsuario = {
        id: nuevoId,
        nombre: nombre,
        edad: parseInt(edad)
    };

    // Agregamos el nuevo usuario al arreglo
    usuarios.push(nuevoUsuario);

    // Devolvemos el usuario creado con un status 201 (Created)
    res.status(201).json(nuevoUsuario);
});


// 4. RUTA PARA ELIMINAR UN USUARIO POR SU ID
// Ejemplo: DELETE /api/usuarios/2
router.delete('/usuarios/:id', (req, res) => {
    const userId = parseInt(req.params.id);
    
    // Buscamos el índice del usuario que queremos eliminar
    const usuarioIndex = usuarios.findIndex(u => u.id === userId);

    if (usuarioIndex !== -1) {
        // Si lo encontramos, lo eliminamos del arreglo usando splice
        usuarios.splice(usuarioIndex, 1);
        res.json({ message: `Usuario con id ${userId} eliminado correctamente.` });
    } else {
        // Si no existe, devolvemos un error 404
        res.status(404).json({ message: 'Usuario no encontrado' });
    }
});


// Exportamos el router para que pueda ser usado en app.js
module.exports = router;