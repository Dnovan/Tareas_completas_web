const express = require('express');

// Importamos las rutas que creamos
const userRoutes = require('./routes/UserRoutes');

// Creamos la aplicación de Express
const app = express();
const PORT = 3000;

// Middleware para que Express entienda JSON en el body de las peticiones
app.use(express.json());

// Configuramos las rutas. Todas las rutas en UserRoutes estarán prefijadas con '/api'
// Por ejemplo: /usuarios se convertirá en /api/usuarios
app.use('/api', userRoutes);

// Ponemos el servidor a escuchar en el puerto 3000
app.listen(PORT, () => {
  console.log(`Servidor iniciado en http://localhost:${PORT}`);
});