const express = require('express');
const app = express();
const PORT = 3000;
app.use((req, res, next) => {
    console.log('Middleware Global 1');
    next();
});
app.use((req, res, next) => {
    console.log('Middleware Global 2');
    next();
});
app.use((req, res, next) => {
    console.log('Middleware Global 3');
    res.send('Respuesta del Middleware 3');
    next();
});
app.get('/', (req, res) => {
    console.log('Ruta GET /');
    res.send('Hola desde la ruta GET /');
});
app.get('/about', (req, res) => {
    console.log('Ruta GET /about');
    res.send('Acerca de nosotros');
});
app.use((err, req, res, next) => {
    console.error('Error detectado:', err.message);
    if (!res.headersSent) {
        res.status(500).send('Algo salió mal!');
    }
});
app.listen(PORT, () => {
    console.log(`Servidor ejecutándose en http://localhost:${PORT}`);
});