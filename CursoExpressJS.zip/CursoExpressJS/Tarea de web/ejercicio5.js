const express = require('express');
const app = express();
const port = 3000;

app.use(express.json());
class ValidationError extends Error {
  constructor(message, details) {
    super(message);
    this.name = 'ValidationError';
    this.statusCode = 422;
    this.details = details;
  }
}

app.post('/products', async (req, res, next) => {
  try {
    const { name, price } = req.body;
    const errors = [];

    if (!name || typeof name !== 'string' || name.length < 3) {
      errors.push({ field: 'name', message: 'El nombre es requerido y debe tener al menos 3 caracteres.' });
    }
    if (price === undefined || typeof price !== 'number' || price <= 0) {
      errors.push({ field: 'price', message: 'El precio es requerido, debe ser un número positivo.' });
    }
    
    if (errors.length > 0) {
      throw new ValidationError('La validación del producto falló', errors);
    }
    
    
    res.status(201).json({ id: Date.now(), name, price });
  } catch (err) {
    next(err); 
  }
});

app.use((err, req, res, next) => {
  console.error(err.stack); 

  if (err instanceof ValidationError) {
    return res.status(err.statusCode).json({
      error: err.message,
      details: err.details
    });
  }
  
  res.status(500).json({ error: 'Ocurrió un error interno en el servidor.' });
});

app.listen(port, () => console.log(`Servidor en http://localhost:${port}`));