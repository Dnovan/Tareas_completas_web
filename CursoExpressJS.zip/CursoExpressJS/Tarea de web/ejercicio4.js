const express = require('express');
const app = express();
const port = 3000;

const users = { 'user-token': { id: 1, role: 'user' }, 'admin-token': { id: 2, role: 'admin' } };

const authenticate = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'No autenticado: Token no proporcionado.' });
  }
  
  const token = authHeader.split(' ')[1];
  const user = users[token];

  if (!user) {
    return res.status(401).json({ error: 'No autenticado: Token inválido.' });
  }

  req.user = user;
  next();
};

const authorize = (requiredRole) => {
  return (req, res, next) => {
    if (req.user.role !== requiredRole) {
      return res.status(403).json({ error: 'Prohibido: No tienes los permisos necesarios.' });
    }
    next();
  };
};

app.delete('/users/:id', authenticate, authorize('admin'), (req, res) => {
  res.json({ message: `Usuario ${req.params.id} eliminado por admin ${req.user.id}` });
});

app.listen(port, () => console.log(`Servidor en http://localhost:${port}`));