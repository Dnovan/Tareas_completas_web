const express = require('express');
const app = express();
const port = 3000;

app.use(express.json());

app.get('/users/:id/books/:isbn', (req, res) => {
  const { id, isbn } = req.params;
  const { limit, offset } = req.query;

  const isbnRegex = /^(?=(?:\D*\d){10}(?:(?:\D*\d){3})?$)[\d-]+$/;
  if (!isbnRegex.test(isbn)) {
    return res.status(400).json({ error: 'Formato de ISBN inválido.' });
  }
  if ((limit && isNaN(parseInt(limit))) || (offset && isNaN(parseInt(offset)))) {
    return res.status(400).json({ error: 'limit y offset deben ser números.' });
  }

  res.json({
    user_id: id,
    book_isbn: isbn,
    options: {
      limit: limit ? parseInt(limit) : 10, 
      offset: offset ? parseInt(offset) : 0, 
    }
  });
});

app.post('/users', (req, res) => {
  const { name, email } = req.body;

  if (!name || !email) {
    return res.status(400).json({ error: 'Nombre y email son requeridos.' });
  }

  res.status(201).json({ id: Date.now(), name, email });
});

app.listen(port, () => console.log(`Servidor en http://localhost:${port}`));