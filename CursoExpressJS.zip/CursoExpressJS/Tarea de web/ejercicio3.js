const express = require('express');
const app = express();
const port = 3000

app.get('/read-headers', (req, res) => {
  const userAgent = req.get('User-Agent');
  const clientIp = req.ip;
  console.log(`User-Agent: ${userAgent}`);
  console.log(`IP del cliente: ${clientIp}`);
  res.json({ userAgent, clientIp });
});

app.get('/set-headers', (req, res) => {
  res.type('json'); 
  
  res.set({
    'Cache-Control': 'no-store', 
    'X-Content-Type-Options': 'nosniff' 
  });
  
  const sessionToken = 'xyz123abc';
  res.cookie('session_id', sessionToken, {
    httpOnly: true, 
    sameSite: 'strict', 
    secure: process.env.NODE_ENV === 'production' 
  });
  
  res.status(200).json({ message: 'Headers y cookie establecidos.' });
});

app.listen(port, () => console.log(`Servidor en http://localhost:${port}`));