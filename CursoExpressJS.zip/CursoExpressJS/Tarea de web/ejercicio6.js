const express = require('express');
const path = require('path');
const fs = require('fs');
const app = express();
const port = 3000;

fs.writeFileSync('report.txt', 'Este es un reporte de prueba.');

app.get('/old-temp', (req, res) => res.redirect(302, '/new')); 
app.get('/old-perm', (req, res) => res.redirect(308, '/new')); 

app.get('/new', (req, res) => res.send('¡Has sido redirigido a la nueva página!'));

app.get('/text', (req, res) => res.send('Esto es texto plano.'));
app.get('/html', (req, res) => res.send('<h1>Esto es HTML</h1>'));
app.get('/json', (req, res) => res.json({ status: 'ok', data: [1, 2, 3] }));
app.get('/file', (req, res) => res.sendFile(path.join(__dirname, 'report.txt')));
app.get('/download', (req, res) => res.download(path.join(__dirname, 'report.txt'), 'informe-personalizado.txt'));

app.listen(port, () => console.log(`Servidor en http://localhost:${port}`));