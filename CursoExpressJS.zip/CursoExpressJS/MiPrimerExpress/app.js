const express = require('express');
const app = express();
const PORT = 3000;
app.use((req, res, next) => {
    console.log('SE HA REALIZADO UNA SOLICITUD');
    next();
});
app.get('/estados', (req, res) => {
    const estados = [
        'Jalisco',
        'Yucatán',
        'Nuevo León',
        'Quintana Roo',
        'Chiapas'
    ];
    res.json(estados);
});
app.get('/numeros-pares', (req, res) => {
    const numerosPares = [];
    for (let i = 1; i <= 10; i++) {
        numerosPares.push(i * 2);
    }
    res.json(numerosPares);
});
app.get('/comparar', (req, res) => {
    const num1 = parseInt(req.query.num1, 10);
    const num2 = parseInt(req.query.num2, 10);
    // Verificamos si los valores son números válidos
    if (isNaN(num1) || isNaN(num2)) {
        return res.status(400).json({ error: 'Debes proporcionar num1 y num2 como parámetros válidos.' });
    }
    const sonIguales = num1 === num2;
    res.json({
        numero1: num1,
        numero2: num2,
        sonIguales: sonIguales
    });
});
// RUTA 4: Genera un error intencional con estado 503
app.get('/mantenimiento', (req, res, next) => {
    // Creamos un nuevo objeto de error
    const error = new Error('SERVIDOR EN MANTENIMIENTO');
    error.status = 503;
    next(error);
});
app.use((req, res, next) => {
    const error = new Error('Ruta no encontrada');
    error.status = 404;
    next(error);
});
app.use((err, req, res, next) => {
    // Obtiene el código de estado del error, o usa 500 (Error Interno del Servidor) si no existe
    const status = err.status || 500;
    const message = err.message || 'Ocurrió un error inesperado.';
    res.status(status).json({
        error: message
    });
});
app.listen(PORT, () => {
    console.log(`Servidor escuchando en http://localhost:${PORT}`);
});