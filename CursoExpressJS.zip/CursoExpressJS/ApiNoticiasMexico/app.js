const express = require('express');
const app = express();
const PORT = 3000;

// Importar Rutas
const profile_routes = require('./routes/ProfileRoute');
const state_routes = require('./routes/StateRoute');
const category_routes = require('./routes/CategoryRoutes');
const new_routes = require('./routes/NewRoute');
const user_routes = require('./routes/UserRoute');

app.use(express.json());

// Usar las rutas con un prefijo '/api'
app.use('/api/perfiles', profile_routes);
app.use('/api/estados', state_routes);
app.use('/api/categorias', category_routes);
app.use('/api/noticias', new_routes);
app.use('/api/usuarios', user_routes);

app.listen(PORT, () => {
    console.log(`Servidor escuchando en http://localhost:${PORT}`);
});

module.exports = app;