const Sequelize = require('sequelize');

const connection = new Sequelize('db_news', 'root', '', {
    host: 'localhost',
    dialect: 'mysql',
    port: 3307 
});

connection.authenticate()
    .then(() => {
        console.log('Se ha establecido conexión con la base de datos ✅');
    })
    .catch(err => {
        console.error('No se pudo establecer conexión con la base de datos:', err);
    });

module.exports = { connection };