const express = require('express');
const { get, getById, create, update, destroy } = require('../controllers/UserController');
const { validatorUserCreate, validatorUserUpdate } = require('../validators/UserValidator');
const router = express.Router();

router.get('/', get);
router.get('/:id', getById);
router.post('/', validatorUserCreate, create);
router.put('/:id', validatorUserUpdate, update);
router.delete('/:id', destroy);

module.exports = router;
