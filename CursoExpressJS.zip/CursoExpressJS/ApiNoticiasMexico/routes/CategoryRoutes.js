const express = require('express');
const { get, getById, create, update, destroy } = require('../controllers/CategoryController');
const { validatorCategoryCreate, validatorCategoryUpdate } = require('../validators/CategoryValidator');
const router = express.Router();

router.get('/', get);
router.get('/:id', getById);
router.post('/', validatorCategoryCreate, create);
router.put('/:id', validatorCategoryUpdate, update);
router.delete('/:id', destroy);

module.exports = router;