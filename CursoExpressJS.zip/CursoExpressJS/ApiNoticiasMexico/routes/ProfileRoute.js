const express = require('express');
const { get, getById, create, update, destroy } = require('../controllers/ProfileController');
const router = express.Router();

router.get('/', get);
router.get('/:id', getById);
router.post('/', create);
router.put('/:id', update);
router.delete('/:id', destroy);

module.exports = router;