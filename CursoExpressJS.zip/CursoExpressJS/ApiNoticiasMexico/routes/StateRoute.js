const express = require('express');
const { get, getById, create, update, destroy } = require('../controllers/StateController');
const { validatorStateRequire, validatorStateOptional } = require('../validators/StateValidator');
const router = express.Router();

router.get('/', get);
router.get('/:id', getById);
router.post('/', validatorStateRequire, create);
router.put('/:id', validatorStateOptional, update);
router.delete('/:id', destroy);

module.exports = router;