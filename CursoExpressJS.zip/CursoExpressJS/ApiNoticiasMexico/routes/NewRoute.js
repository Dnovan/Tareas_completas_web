const express = require('express');
const { get, getById, create, update, destroy } = require('../controllers/NewController');
const { validatorNewCreate, validatorNewUpdate } = require('../validators/NewValidator');
const router = express.Router();

router.get('/', get);
router.get('/:id', getById);
router.post('/', validatorNewCreate, create);
router.put('/:id', validatorNewUpdate, update);
router.delete('/:id', destroy);

module.exports = router;